# VSE-paper
Code and data for "Accounting for spatial varying sampling effort due to accessibility in CitizenScience data:  A case study of moose in Norway"


In the folder MooseExample, the R code for the example is available. The code spde-book-functions.R is taken from http://www.r-inla.org/spde-book. It is part of the book Advanced Spatial Modeling with Stochastic Partial Differential Equations Using R and INLA
Elias T. Krainski, Virgilio Gómez-Rubio, Haakon Bakka, Amanda Lenzi, Daniela Castro-Camilo, Daniel Simpson, Finn Lindgren and Håvard Rue
CRC Press/Taylor and Francis Group, 2019. 
